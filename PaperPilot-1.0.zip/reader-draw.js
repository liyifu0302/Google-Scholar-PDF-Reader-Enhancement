(function () {
  "use strict";

  const SVG_NS = "http://www.w3.org/2000/svg";
  const STORAGE_PREFIX = "gsr-draw-v1:";
  const COLORS = ["#d93025", "#1a73e8", "#188038", "#202124"];

  const state = {
    enabled: false,
    color: COLORS[0],
    width: 3,
    key: "",
    data: { version: 1, pages: {} },
    history: [],
    current: null,
    drawButton: null,
    tools: null,
    scheduled: false
  };

  function hashString(value) {
    let hash = 2166136261;
    for (let i = 0; i < value.length; i++) {
      hash ^= value.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(36);
  }

  function getDocumentKey() {
    const title = (document.querySelector(".gsr-tb-title")?.textContent || document.title || location.href).trim();
    return STORAGE_PREFIX + hashString(location.pathname + "|" + location.hash + "|" + title);
  }

  function loadData() {
    try {
      const parsed = JSON.parse(localStorage.getItem(state.key) || "");
      state.data = parsed && parsed.version === 1 && parsed.pages ? parsed : { version: 1, pages: {} };
    } catch (error) {
      state.data = { version: 1, pages: {} };
    }
    rebuildHistory();
  }

  function saveData() {
    try {
      localStorage.setItem(state.key, JSON.stringify(state.data));
    } catch (error) {
      console.warn("Google Scholar Reader draw: unable to save drawings", error);
    }
  }

  function rebuildHistory() {
    state.history = [];
    for (const [page, strokes] of Object.entries(state.data.pages)) {
      for (const stroke of strokes || []) {
        state.history.push({ page, id: stroke.id });
      }
    }
  }

  function refreshDocument() {
    const key = getDocumentKey();
    if (state.key !== key) {
      state.key = key;
      loadData();
      renderAllPages();
    }
  }

  function makeButton(className, label, svg) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "gsr-flat-btn " + className;
    button.innerHTML = svg;
    button.setAttribute("aria-label", label);
    button.title = label;
    return button;
  }

  function installToolbar() {
    const center = document.querySelector(".gsr-tb-ctr");
    if (!center || document.querySelector(".gsr-draw-tools")) {
      return;
    }

    const tools = document.createElement("span");
    tools.className = "gsr-draw-tools";

    const drawButton = makeButton(
      "gsr-draw-btn",
      "Draw",
      '<svg viewBox="0 0 21 21"><path d="M4 15.8L4.8 12.1L13.6 3.3C14.2 2.7 15.2 2.7 15.8 3.3L17.7 5.2C18.3 5.8 18.3 6.8 17.7 7.4L8.9 16.2L5.2 17L4 15.8ZM6.1 12.9L5.7 15.1L7.9 14.7L14.2 8.4L12.4 6.6L6.1 12.9ZM13.4 5.6L15.2 7.4L16.6 6L14.8 4.2L13.4 5.6Z"/></svg>'
    );
    drawButton.addEventListener("click", function () {
      setDrawMode(!state.enabled);
    });

    const undoButton = makeButton(
      "gsr-draw-undo",
      "Undo drawing",
      '<svg viewBox="0 0 21 21"><path d="M8.2 6.2H14.1C16.5 6.2 18.3 8 18.3 10.3C18.3 12.7 16.5 14.5 14.1 14.5H6.4V13H14.1C15.6 13 16.8 11.8 16.8 10.3C16.8 8.8 15.6 7.7 14.1 7.7H8.2L10.7 10.2L9.6 11.3L5.2 6.9L9.6 2.6L10.7 3.7L8.2 6.2Z"/></svg>'
    );
    undoButton.addEventListener("click", undoStroke);

    const clearButton = makeButton(
      "gsr-draw-clear",
      "Clear drawings",
      '<svg viewBox="0 0 21 21"><path d="M7 18C6.6 18 6.2 17.9 5.9 17.6C5.6 17.3 5.5 16.9 5.5 16.5V6H4.5V4.5H8V3.5H13V4.5H16.5V6H15.5V16.5C15.5 16.9 15.4 17.3 15.1 17.6C14.8 17.9 14.4 18 14 18H7ZM14 6H7V16.5H14V6ZM8.5 15H10V7.5H8.5V15ZM11 15H12.5V7.5H11V15Z"/></svg>'
    );
    clearButton.addEventListener("click", clearDrawings);

    tools.append(drawButton, undoButton, clearButton);

    for (const color of COLORS) {
      const swatch = makeButton("gsr-draw-swatch", "Draw color", "");
      swatch.style.setProperty("--gsr-draw-color", color);
      swatch.dataset.color = color;
      swatch.addEventListener("click", function () {
        state.color = color;
        updateToolbarState();
      });
      tools.appendChild(swatch);
    }

    center.appendChild(tools);
    state.tools = tools;
    state.drawButton = drawButton;
    updateToolbarState();
  }

  function updateToolbarState() {
    document.querySelector(".gsr-root")?.classList.toggle("gsr-draw-mode", state.enabled);
    state.tools?.classList.toggle("gsr-draw-active", state.enabled);
    state.drawButton?.classList.toggle("gsr-select", state.enabled);
    state.drawButton?.setAttribute("aria-pressed", state.enabled ? "true" : "false");
    for (const swatch of document.querySelectorAll(".gsr-draw-swatch")) {
      swatch.classList.toggle("gsr-select", swatch.dataset.color === state.color);
    }
  }

  function setDrawMode(enabled) {
    state.enabled = enabled;
    updateToolbarState();
    ensurePages();
  }

  function ensurePages() {
    refreshDocument();
    for (const page of document.querySelectorAll(".gsr-page")) {
      ensureLayer(page);
    }
  }

  function ensureLayer(page) {
    const pageNumber = page.getAttribute("data-pn");
    if (!pageNumber) {
      return null;
    }
    let layer = page.querySelector(".gsr-draw-layer");
    if (!layer) {
      layer = document.createElementNS(SVG_NS, "svg");
      layer.classList.add("gsr-draw-layer");
      layer.setAttribute("viewBox", "0 0 1 1");
      layer.setAttribute("preserveAspectRatio", "none");
      layer.dataset.page = pageNumber;
      layer.addEventListener("pointerdown", startStroke);
      layer.addEventListener("pointermove", moveStroke);
      layer.addEventListener("pointerup", finishStroke);
      layer.addEventListener("pointercancel", cancelStroke);
      page.appendChild(layer);
    }
    if (layer.dataset.drawKey !== state.key) {
      renderLayer(layer, pageNumber);
      layer.dataset.drawKey = state.key;
    }
    return layer;
  }

  function makeStrokeElement(stroke) {
    const line = document.createElementNS(SVG_NS, "polyline");
    line.classList.add("gsr-draw-stroke");
    line.setAttribute("stroke", stroke.color || COLORS[0]);
    line.setAttribute("stroke-width", String(stroke.width || 3));
    line.setAttribute("vector-effect", "non-scaling-stroke");
    line.setAttribute("points", stroke.points.map(formatPoint).join(" "));
    return line;
  }

  function formatPoint(point) {
    return point[0].toFixed(5) + "," + point[1].toFixed(5);
  }

  function renderLayer(layer, pageNumber) {
    layer.textContent = "";
    const strokes = state.data.pages[pageNumber] || [];
    for (const stroke of strokes) {
      layer.appendChild(makeStrokeElement(stroke));
    }
  }

  function renderAllPages() {
    for (const layer of document.querySelectorAll(".gsr-draw-layer")) {
      renderLayer(layer, layer.dataset.page);
      layer.dataset.drawKey = state.key;
    }
  }

  function pointFromEvent(event, layer) {
    const rect = layer.getBoundingClientRect();
    const x = rect.width ? (event.clientX - rect.left) / rect.width : 0;
    const y = rect.height ? (event.clientY - rect.top) / rect.height : 0;
    return [Math.max(0, Math.min(1, x)), Math.max(0, Math.min(1, y))];
  }

  function startStroke(event) {
    if (!state.enabled || event.button !== 0) {
      return;
    }
    const layer = event.currentTarget;
    const pageNumber = layer.dataset.page;
    if (!pageNumber) {
      return;
    }
    event.preventDefault();
    event.stopPropagation();
    layer.setPointerCapture?.(event.pointerId);

    const stroke = {
      id: Date.now().toString(36) + Math.random().toString(36).slice(2, 8),
      color: state.color,
      width: state.width,
      points: [pointFromEvent(event, layer)]
    };
    const element = makeStrokeElement(stroke);
    layer.appendChild(element);
    state.current = { layer, pageNumber, stroke, element, pointerId: event.pointerId };
  }

  function moveStroke(event) {
    const current = state.current;
    if (!current || current.pointerId !== event.pointerId) {
      return;
    }
    event.preventDefault();
    event.stopPropagation();
    const point = pointFromEvent(event, current.layer);
    const previous = current.stroke.points[current.stroke.points.length - 1];
    const rect = current.layer.getBoundingClientRect();
    if (Math.abs(point[0] - previous[0]) * rect.width < 1.5 &&
        Math.abs(point[1] - previous[1]) * rect.height < 1.5) {
      return;
    }
    current.stroke.points.push(point);
    current.element.setAttribute("points", current.stroke.points.map(formatPoint).join(" "));
  }

  function finishStroke(event) {
    const current = state.current;
    if (!current || current.pointerId !== event.pointerId) {
      return;
    }
    event.preventDefault();
    event.stopPropagation();
    current.layer.releasePointerCapture?.(event.pointerId);
    state.current = null;

    if (current.stroke.points.length < 2) {
      current.element.remove();
      return;
    }
    const strokes = state.data.pages[current.pageNumber] || [];
    strokes.push(current.stroke);
    state.data.pages[current.pageNumber] = strokes;
    state.history.push({ page: current.pageNumber, id: current.stroke.id });
    saveData();
  }

  function cancelStroke(event) {
    if (state.current && state.current.pointerId === event.pointerId) {
      state.current.element.remove();
      state.current = null;
    }
  }

  function undoStroke() {
    refreshDocument();
    let last = state.history.pop();
    while (last) {
      const strokes = state.data.pages[last.page] || [];
      const index = strokes.findIndex(stroke => stroke.id === last.id);
      if (index >= 0) {
        strokes.splice(index, 1);
        if (strokes.length) {
          state.data.pages[last.page] = strokes;
        } else {
          delete state.data.pages[last.page];
        }
        saveData();
        const layer = document.querySelector('.gsr-draw-layer[data-page="' + CSS.escape(last.page) + '"]');
        if (layer) {
          renderLayer(layer, last.page);
        }
        return;
      }
      last = state.history.pop();
    }
  }

  function hasDrawings() {
    return Object.values(state.data.pages).some(strokes => strokes && strokes.length);
  }

  function clearDrawings() {
    refreshDocument();
    if (!hasDrawings() || !confirm("Clear all drawings for this PDF?")) {
      return;
    }
    state.data = { version: 1, pages: {} };
    state.history = [];
    saveData();
    renderAllPages();
  }

  function schedule() {
    if (state.scheduled) {
      return;
    }
    state.scheduled = true;
    requestAnimationFrame(function () {
      state.scheduled = false;
      installToolbar();
      ensurePages();
    });
  }

  function start() {
    refreshDocument();
    installToolbar();
    ensurePages();
    new MutationObserver(schedule).observe(document.body, { childList: true, subtree: true });
    window.addEventListener("resize", schedule);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
