(function () {
  "use strict";

  const SCHOLAR_ORIGIN = "https://scholar.google.com";
  const MAX_AUTHORS = 12;
  const MAX_RESULTS = 4;
  const AFFILIATION_RE = /\b(?:university|college|school|department|dept\.?|faculty|institute|institution|laboratory|lab\.?|center|centre|business school|medical school|hospital|academy|polytechnic|cnrs|inria|nber|cepr)\b/i;
  const STOP_RE = /^\s*(?:abstract|keywords?|introduction|1\.?\s+introduction|jel\s+classification|acknowledg(?:e)?ments?)\b/i;
  const BAD_NAME_RE = /\b(?:abstract|article|journal|review|press|copyright|doi|http|www|university|department|school|college|institute|faculty|laboratory|center|centre|keywords?|introduction|appendix|figure|table)\b/i;
  const NAME_WORD_RE = /^[A-Za-z][A-Za-z'.-]*$/;
  const FOOTNOTE_MARK_RE = /[0-9*\u2020\u2021\u00a7\u00b6\u00b9\u00b2\u00b3\u2070-\u2079\u1d43-\u1dbf]+/g;
  const NAME_PARTICLE_RE = /^(?:da|de|del|della|der|di|du|la|le|van|von)$/i;
  const SINGLE_AFFILIATION_RE = /\b(?!da\b|de\b|del\b|della\b|der\b|di\b|du\b|la\b|le\b|van\b|von\b)[a-z]\b/g;
  const TITLE_LINE_RE = /[?!]\s*$|:\s+[A-Z]|\b(?:after|between|during|through|versus|vs\.?|among|across|within|without|against|whether|toward|towards|beyond|driven|based|examining|evidence|implications|determinants|effects?|impact|role|analysis|empirical|theoretical|turnover|performance|returns?|market|stock|pricing|valuation|risk|model|approach|strategy|policy|firms?|corporate|financial|economic|bidders?|acquisitions?|mergers?|quality|reporting|deals?|bust|fired)\b/i;

  const state = {
    api: null,
    indexPromise: null,
    index: null,
    scheduled: false,
    preview: null,
    hideTimer: 0,
    token: 0,
    pinned: false,
    cache: new Map()
  };

  function waitForApi() {
    if (window.__gsrTablePreviewApi) {
      state.api = window.__gsrTablePreviewApi;
      return Promise.resolve(state.api);
    }
    return new Promise(resolve => {
      const started = Date.now();
      const timer = setInterval(function () {
        if (window.__gsrTablePreviewApi || Date.now() - started > 15000) {
          clearInterval(timer);
          state.api = window.__gsrTablePreviewApi || null;
          resolve(state.api);
        }
      }, 100);
    });
  }

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function lineText(items) {
    let text = "";
    let previous = null;
    for (const item of items) {
      const part = item.text || "";
      if (!part) {
        continue;
      }
      if (previous && text && !/\s$/.test(text) && !/^\s/.test(part)) {
        const gap = item.left - (previous.left + previous.width);
        if (gap > Math.max(1.5, item.height * 0.16)) {
          text += " ";
        }
      }
      text += part;
      previous = item;
    }
    return text.replace(/\s+/g, " ").trim();
  }

  function mergeBounds(items) {
    let left = Infinity;
    let top = Infinity;
    let right = -Infinity;
    let bottom = -Infinity;
    for (const item of items) {
      left = Math.min(left, item.left);
      top = Math.min(top, item.top);
      right = Math.max(right, item.left + item.width);
      bottom = Math.max(bottom, item.top + item.height);
    }
    return {
      left,
      top,
      width: Math.max(0, right - left),
      height: Math.max(0, bottom - top)
    };
  }

  function makeLines(items) {
    const visible = (items || [])
      .filter(item => item.text && item.text.trim() && Number.isFinite(item.left) && Number.isFinite(item.top))
      .sort((a, b) => a.top - b.top || a.left - b.left);
    const rows = [];
    for (const item of visible) {
      const row = rows[rows.length - 1];
      const tolerance = Math.max(2, Math.min(9, Math.max(item.height || 0, row ? row.height : 0) * 0.7));
      if (row && Math.abs(item.top - row.top) <= tolerance) {
        row.items.push(item);
        row.top = (row.top * (row.items.length - 1) + item.top) / row.items.length;
        row.height = Math.max(row.height, item.height || 0);
      } else {
        rows.push({ top: item.top, height: item.height || 0, items: [item] });
      }
    }
    return rows.map(row => {
      row.items.sort((a, b) => a.left - b.left);
      return {
        text: lineText(row.items),
        bounds: mergeBounds(row.items),
        items: row.items
      };
    }).filter(line => line.text);
  }

  function cleanAuthorText(text) {
    return text
      .replace(/\S+@\S+/g, " ")
      .replace(/\bORCID\b.*$/i, " ")
      .replace(/\[[^\]]{1,12}\]/g, " ")
      .replace(/\((?:\s*[0-9a-z*\u2020\u2021\u00a7\u00b6,; ]+\s*)\)/gi, " ")
      .replace(FOOTNOTE_MARK_RE, " ")
      .replace(SINGLE_AFFILIATION_RE, " ")
      .replace(/\([^)]*(?:university|department|school|email|orcid)[^)]*\)/gi, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  function stripAuthorPart(text) {
    let value = cleanAuthorText(text)
      .replace(/^[,;|&\s]+|[,;|&\s]+$/g, "")
      .replace(/\b(?:and)\b$/i, "")
      .replace(/\s+/g, " ")
      .trim();
    let words = value.split(/\s+/).filter(Boolean);
    while (words.length > 2) {
      const last = words[words.length - 1].replace(/[.,]/g, "");
      if (/^[A-Z]$/i.test(last) && !NAME_PARTICLE_RE.test(last)) {
        words.pop();
      } else {
        break;
      }
    }
    value = words.join(" ").replace(/\s+/g, " ").trim();
    return value;
  }

  function normalizeSpacesWithMap(text) {
    const chars = [];
    const positions = [];
    let pendingSpace = false;
    for (let i = 0; i < text.length; i++) {
      const char = text[i];
      if (/\s/.test(char)) {
        pendingSpace = true;
        continue;
      }
      if (pendingSpace && chars.length && chars[chars.length - 1] !== " ") {
        chars.push(" ");
        positions.push(i);
      }
      chars.push(char);
      positions.push(i);
      pendingSpace = false;
    }
    return { text: chars.join(""), positions };
  }

  function makeSegment(name, start, end) {
    const normalized = normalizeSpacesWithMap(name);
    if (!normalized.text) {
      return null;
    }
    return {
      name: normalized.text.trim(),
      start: start + (normalized.positions[0] || 0),
      end: start + (normalized.positions[normalized.positions.length - 1] || 0) + 1
    };
  }

  function isInitialWord(word) {
    return /^[A-Z]\.?$/i.test(word.replace(/[.,]/g, ""));
  }

  function isParticleWord(word) {
    return NAME_PARTICLE_RE.test(word.replace(/[.,]/g, ""));
  }

  function tokenizeNameLine(text) {
    const tokens = [];
    const pattern = /[A-Za-z][A-Za-z'.-]*/g;
    let match;
    while ((match = pattern.exec(text))) {
      tokens.push({ text: match[0], start: match.index, end: match.index + match[0].length });
    }
    return tokens;
  }

  function segmentScore(groups) {
    let score = groups.length * 20;
    for (const group of groups) {
      const words = group.map(token => token.text);
      if (words.length === 2) {
        score += 4;
      } else if (words.length === 3 && words.some(isInitialWord)) {
        score += 5;
      } else if (words.length === 3) {
        score += 2;
      } else {
        score -= 2;
      }
      if (words.some(isParticleWord)) {
        score += 1;
      }
      if (isParticleWord(words[words.length - 1])) {
        score -= 12;
      }
    }
    return score;
  }

  function splitCompactAuthorLine(text) {
    const tokens = tokenizeNameLine(text);
    if (tokens.length < 4 || tokens.length > 18) {
      return [];
    }
    let best = null;
    function visit(index, groups) {
      if (index >= tokens.length) {
        if (groups.length > 1) {
          const score = segmentScore(groups);
          if (!best || score > best.score) {
            best = { score, groups: groups.slice() };
          }
        }
        return;
      }
      for (const size of [2, 3, 4]) {
        const next = index + size;
        if (next > tokens.length) {
          continue;
        }
        const group = tokens.slice(index, next);
        const value = group.map(token => token.text).join(" ");
        const lastWord = group[group.length - 1].text;
        if (isNameCandidate(value) && !isParticleWord(lastWord) && !isInitialWord(lastWord)) {
          groups.push(group);
          visit(next, groups);
          groups.pop();
        }
      }
    }
    visit(0, []);
    if (!best) {
      return [];
    }
    return best.groups.map(group => ({
      name: group.map(token => token.text).join(" "),
      start: group[0].start,
      end: group[group.length - 1].end
    }));
  }

  function isNameCandidate(value) {
    const text = value.replace(/\s+/g, " ").trim();
    if (text.length < 4 || text.length > 64 || BAD_NAME_RE.test(text)) {
      return false;
    }
    const words = text.split(/\s+/).filter(Boolean);
    if (words.length < 2 || words.length > 6) {
      return false;
    }
    let fullWords = 0;
    for (const word of words) {
      const clean = word.replace(/[.,]/g, "");
      if (!NAME_WORD_RE.test(clean)) {
        return false;
      }
      if (clean.length > 1 && !/^[A-Z]\.?$/.test(clean)) {
        fullWords++;
      }
    }
    return fullWords >= 1;
  }

  function splitAuthorSegments(text) {
    const value = cleanAuthorText(text);
    if (!value) {
      return [];
    }
    const segments = [];
    const separator = /\s*(?:,|;|\||&|\band\b)\s*/gi;
    let start = 0;
    let hadSeparator = false;
    let match;
    while ((match = separator.exec(value))) {
      hadSeparator = true;
      const part = value.slice(start, match.index);
      const segment = makeSegment(stripAuthorPart(part), start, match.index);
      if (segment && isNameCandidate(segment.name)) {
        segments.push(segment);
      }
      start = separator.lastIndex;
    }
    const tail = value.slice(start);
    const tailSegment = makeSegment(stripAuthorPart(tail), start, value.length);
    if (tailSegment && isNameCandidate(tailSegment.name)) {
      segments.push(tailSegment);
    }
    if (hadSeparator && segments.length) {
      return segments;
    }
    const compact = splitCompactAuthorLine(stripAuthorPart(value)).filter(segment => isNameCandidate(segment.name));
    if (compact.length > 1) {
      return compact;
    }
    if (segments.length) {
      return segments;
    }
    const stripped = stripAuthorPart(value);
    if (isNameCandidate(stripped)) {
      return [{ name: stripped, start: 0, end: stripped.length }];
    }
    return [];
  }

  function splitAuthorNames(text) {
    return splitAuthorSegments(text).map(segment => segment.name);
  }

  function isLikelyAuthorLine(line) {
    const text = line.text;
    if (!text || text.length > 180 || BAD_NAME_RE.test(text)) {
      return false;
    }
    if (/[?!]\s*$/.test(text)) {
      return false;
    }
    if (/[.!?]$/.test(text) && text.length > 80) {
      return false;
    }
    if (TITLE_LINE_RE.test(text)) {
      return false;
    }
    return splitAuthorNames(text).length > 0;
  }

  function institutionFromLine(text) {
    const value = text.replace(/\S+@\S+/g, " ").replace(/\s+/g, " ").trim();
    const patterns = [
      /\b([A-Z][A-Za-z&.' -]{2,80}\s+University)\b/,
      /\b(University\s+of\s+[A-Z][A-Za-z&.' -]{2,80})\b/,
      /\b([A-Z][A-Za-z&.' -]{2,80}\s+(?:College|Institute|School|Business School|Medical School|Hospital|Academy))\b/
    ];
    for (const pattern of patterns) {
      const match = pattern.exec(value);
      if (match) {
        return match[1].trim();
      }
    }
    return AFFILIATION_RE.test(value) ? value.slice(0, 120) : "";
  }

  function maxItemHeight(line) {
    if (line.items && line.items.length) {
      let max = 0;
      for (const item of line.items) {
        const h = item.height || (item.rect ? item.rect.height : 0);
        if (h > max) max = h;
      }
      if (max > 0) return max;
    }
    return line.bounds ? line.bounds.height : 0;
  }

  function findNearestAffiliation(authorLineIndex, allLines, maxLook) {
    const limit = Math.min(authorLineIndex + (maxLook || 4), allLines.length);
    const affs = [];
    for (let j = authorLineIndex + 1; j < limit; j++) {
      const lt = (allLines[j].text || "").trim();
      if (STOP_RE.test(lt)) break;
      const inst = institutionFromLine(lt);
      if (inst) {
        affs.push(inst);
      } else if (affs.length) {
        break;
      }
    }
    return affs;
  }

  function findAuthorIndex(page) {
    const lines = makeLines(page.items);
    const stopIndex = lines.findIndex(line => STOP_RE.test(line.text));
    const limit = stopIndex > 0 ? stopIndex : Math.min(lines.length, 28);
    const front = lines.slice(0, limit).filter(line => line.bounds.top < page.height * 0.62);
    const affiliations = front
      .map(line => institutionFromLine(line.text))
      .filter(Boolean)
      .slice(0, 4);
    const affiliationHint = affiliations.join(" ");

    let searchLines = [];
    const firstAff = front.findIndex(line => AFFILIATION_RE.test(line.text) || /\S+@\S+/.test(line.text));
    if (firstAff > 0) {
      let previousTop = front[firstAff].bounds.top;
      let foundAuthorLine = false;
      let authorHeight = 0;
      for (let i = firstAff - 1; i >= Math.max(0, firstAff - 6); i--) {
        const line = front[i];
        const lineH = maxItemHeight(line);
        const gap = previousTop - (line.bounds.top + line.bounds.height);
        if (foundAuthorLine && gap > Math.max(28, line.bounds.height * 2.2)) {
          break;
        }
        if (foundAuthorLine && authorHeight > 0 && lineH > authorHeight * 1.3) {
          break;
        }
        if (isLikelyAuthorLine(line)) {
          searchLines.unshift(line);
          foundAuthorLine = true;
          if (!authorHeight || lineH < authorHeight) {
            authorHeight = lineH;
          }
          previousTop = line.bounds.top;
        } else if (foundAuthorLine) {
          break;
        }
      }
      for (let i = firstAff + 1; i < front.length; i++) {
        const line = front[i];
        if (STOP_RE.test(line.text)) break;
        if (isLikelyAuthorLine(line)) {
          let nearAff = false;
          for (let j = i + 1; j <= Math.min(i + 3, front.length - 1); j++) {
            if (AFFILIATION_RE.test(front[j].text) || /\S+@\S+/.test(front[j].text)) {
              nearAff = true;
              break;
            }
          }
          if (nearAff && !searchLines.includes(line)) {
            searchLines.push(line);
          }
        }
      }
    } else {
      const candidates = front.slice(1, Math.min(front.length, 12));
      const heights = candidates.map(l => maxItemHeight(l)).filter(h => h > 0).sort((a, b) => a - b);
      const medianH = heights.length >= 3 ? heights[Math.floor(heights.length / 2)] : 0;
      searchLines = candidates.filter(line => {
        return !(medianH > 0 && maxItemHeight(line) > medianH * 1.3);
      });
    }

    const authors = [];
    for (const line of searchLines) {
      if (!isLikelyAuthorLine(line)) {
        continue;
      }
      const lineIdx = front.indexOf(line);
      const localAffs = lineIdx >= 0 ? findNearestAffiliation(lineIdx, front, 5) : [];
      const authorInstitutions = localAffs.length ? localAffs : affiliations;
      const authorAffHint = localAffs.length ? localAffs.join(" ") : affiliationHint;
      for (const segment of splitAuthorSegments(line.text)) {
        const name = segment.name;
        if (authors.some(author => author.name.toLowerCase() === name.toLowerCase())) {
          continue;
        }
        authors.push({
          name,
          nameStart: segment.start,
          nameEnd: segment.end,
          page: 1,
          lineText: line.text,
          lineBounds: line.bounds,
          affiliationHint: authorAffHint,
          institutions: authorInstitutions,
          top: line.bounds.top
        });
        if (authors.length >= MAX_AUTHORS) {
          break;
        }
      }
      if (authors.length >= MAX_AUTHORS) {
        break;
      }
    }

    return { authors, affiliations, page, lines };
  }

  async function buildIndex() {
    if (state.index) {
      return state.index;
    }
    if (state.indexPromise) {
      return state.indexPromise;
    }
    state.indexPromise = (async function () {
      const api = await waitForApi();
      const started = Date.now();
      while (api && api.numPages() <= 0 && Date.now() - started < 15000) {
        await new Promise(resolve => setTimeout(resolve, 100));
      }
      if (!api || api.numPages() <= 0) {
        state.index = { authors: [], affiliations: [] };
        return state.index;
      }
      try {
        const page = await api.getTextPage(1);
        state.index = findAuthorIndex(page);
      } catch (error) {
        console.warn("Google Scholar Reader author preview: unable to index authors", error);
        state.index = { authors: [], affiliations: [] };
      }
      scheduleAnnotate();
      return state.index;
    })();
    return state.indexPromise;
  }

  function ensureLayer(page) {
    let layer = page.querySelector(":scope > .gsr-author-ref-layer");
    if (!layer) {
      layer = document.createElement("div");
      layer.className = "gsr-author-ref-layer";
      page.appendChild(layer);
    }
    return layer;
  }

  function getMatchRect(span, start, end) {
    const node = span.firstChild;
    if (!node || node.nodeType !== Node.TEXT_NODE) {
      return span.getBoundingClientRect();
    }
    const range = document.createRange();
    range.setStart(node, Math.min(start, node.length));
    range.setEnd(node, Math.min(end, node.length));
    const rects = Array.from(range.getClientRects()).filter(rect => rect.width > 0 && rect.height > 0);
    const rect = rects[0] || range.getBoundingClientRect();
    range.detach();
    return rect;
  }

  function mergeClientRects(rects) {
    let left = Infinity;
    let top = Infinity;
    let right = -Infinity;
    let bottom = -Infinity;
    for (const rect of rects) {
      left = Math.min(left, rect.left);
      top = Math.min(top, rect.top);
      right = Math.max(right, rect.right);
      bottom = Math.max(bottom, rect.bottom);
    }
    return {
      left,
      top,
      right,
      bottom,
      width: Math.max(0, right - left),
      height: Math.max(0, bottom - top)
    };
  }

  function isLikelyAffiliationMarkerPart(item, rowHeight) {
    const text = (item.text || "").trim();
    if (!text || text.length > 10) {
      return false;
    }
    if (/^[0-9*\u2020\u2021\u00a7\u00b6\u00b9\u00b2\u00b3\u2070-\u2079\s,;]+$/.test(text)) {
      return true;
    }
    if (/^[a-z](?:\s*[,;]\s*[a-z])*,?$/.test(text) && item.rect.height < rowHeight * 0.9) {
      return true;
    }
    return false;
  }

  function makeDomLines(textLayer) {
    const spans = Array.from(textLayer.querySelectorAll(".gsr-text:not(.gsr-hide)"))
      .map(span => ({
        span,
        text: span.textContent || "",
        rect: span.getBoundingClientRect()
      }))
      .filter(item => item.text.trim() && item.rect.width > 0 && item.rect.height > 0)
      .sort((a, b) => a.rect.top - b.rect.top || a.rect.left - b.rect.left);

    const rows = [];
    for (const item of spans) {
      const row = rows[rows.length - 1];
      const tolerance = Math.max(2, Math.min(9, Math.max(item.rect.height || 0, row ? row.height : 0) * 0.7));
      if (row && Math.abs(item.rect.top - row.top) <= tolerance) {
        row.items.push(item);
        row.top = (row.top * (row.items.length - 1) + item.rect.top) / row.items.length;
        row.height = Math.max(row.height, item.rect.height || 0);
      } else {
        rows.push({ top: item.rect.top, height: item.rect.height || 0, items: [item] });
      }
    }

    return rows.map(row => {
      row.items.sort((a, b) => a.rect.left - b.rect.left);
      let text = "";
      let authorText = "";
      let previous = null;
      let previousAuthor = null;
      const parts = [];
      const rects = [];
      for (const item of row.items) {
        if (previous && text && !/\s$/.test(text) && !/^\s/.test(item.text)) {
          const gap = item.rect.left - previous.rect.right;
          if (gap > Math.max(1.5, item.rect.height * 0.16)) {
            text += " ";
          }
        }
        const start = text.length;
        text += item.text;
        parts.push({
          span: item.span,
          text: item.text,
          start,
          end: text.length
        });
        rects.push(item.rect);
        if (!isLikelyAffiliationMarkerPart(item, row.height)) {
          if (previousAuthor && authorText && !/\s$/.test(authorText) && !/^\s/.test(item.text)) {
            const gap = item.rect.left - previousAuthor.rect.right;
            if (gap > Math.max(1.5, item.rect.height * 0.16)) {
              authorText += " ";
            }
          }
          authorText += item.text;
          previousAuthor = item;
        }
        previous = item;
      }
      return {
        text,
        authorText: authorText.replace(/\s+/g, " ").trim(),
        parts,
        bounds: mergeClientRects(rects)
      };
    }).filter(line => line.text.trim());
  }

  function normalizeNameSearch(text) {
    const chars = [];
    const positions = [];
    let pendingSpace = false;
    for (let i = 0; i < text.length; i++) {
      const char = text[i];
      if (/\s/.test(char) || /[0-9*\u2020\u2021\u00a7\u00b6]/.test(char)) {
        pendingSpace = true;
        continue;
      }
      if (pendingSpace && chars.length && chars[chars.length - 1] !== " ") {
        chars.push(" ");
        positions.push(i);
      }
      chars.push(char.toLowerCase());
      positions.push(i);
      pendingSpace = false;
    }
    while (chars.length && chars[chars.length - 1] === " ") {
      chars.pop();
      positions.pop();
    }
    return { text: chars.join(""), positions };
  }

  function findNameInDomLine(line, name) {
    const haystack = normalizeNameSearch(line.text);
    const needle = normalizeNameSearch(name);
    if (!needle.text) {
      return null;
    }
    const start = haystack.text.indexOf(needle.text);
    if (start < 0) {
      return null;
    }
    const end = start + needle.text.length - 1;
    return {
      start: haystack.positions[start],
      end: haystack.positions[end] + 1
    };
  }

  function rectFromDomLine(line, start, end) {
    const rects = [];
    for (const part of line.parts) {
      if (part.end <= start || part.start >= end) {
        continue;
      }
      const localStart = Math.max(0, start - part.start);
      const localEnd = Math.min(part.text.length, end - part.start);
      if (localStart < localEnd) {
        const rect = getMatchRect(part.span, localStart, localEnd);
        if (rect.width > 0 && rect.height > 0) {
          rects.push(rect);
        }
      }
    }
    return rects.length ? mergeClientRects(rects) : null;
  }

  function scoreDomAuthorLine(line, author, pageRect, sourcePage) {
    const text = line.text.replace(/\s+/g, " ").trim();
    if (!text || text.length > 220 || BAD_NAME_RE.test(text)) {
      return -1;
    }
    const relTop = line.bounds.top - pageRect.top;
    if (relTop < -4 || relTop > pageRect.height * 0.68) {
      return -1;
    }
    const lineKey = normalizeNameSearch(text).text;
    const authorKey = normalizeNameSearch(author.name).text;
    if (!lineKey.includes(authorKey)) {
      return -1;
    }
    let score = 1;
    const sourceKey = normalizeNameSearch(author.lineText || "").text;
    if (sourceKey) {
      if (lineKey === sourceKey) {
        score += 12;
      } else if (lineKey.includes(sourceKey) || sourceKey.includes(lineKey)) {
        score += 8;
      }
    }
    if (sourcePage && Number.isFinite(author.top) && Number.isFinite(sourcePage.height) && sourcePage.height > 0) {
      const expectedTop = pageRect.height * (author.top / sourcePage.height);
      const delta = Math.abs(relTop - expectedTop);
      if (delta < Math.max(18, pageRect.height * 0.025)) {
        score += 5;
      } else if (delta < Math.max(36, pageRect.height * 0.055)) {
        score += 2;
      }
    }
    if (splitAuthorNames(text).some(name => normalizeNameSearch(name).text === authorKey)) {
      score += 4;
    }
    return score;
  }

  function authorKey(name) {
    return normalizeNameSearch(stripAuthorPart(name || "")).text;
  }

  function addUniqueLine(lines, line) {
    if (line && !lines.includes(line)) {
      lines.push(line);
    }
  }

  function isLikelyRenderedAuthorLine(line, pageRect) {
    const text = (line.authorText || line.text).replace(/\s+/g, " ").trim();
    if (!text || text.length > 220 || BAD_NAME_RE.test(text)) {
      return false;
    }
    if (/[?!]\s*$/.test(text)) {
      return false;
    }
    if (/[.!?]$/.test(text) && text.length > 80) {
      return false;
    }
    if (TITLE_LINE_RE.test(text)) {
      return false;
    }
    const relTop = line.bounds.top - pageRect.top;
    if (relTop < -4 || relTop > pageRect.height * 0.68) {
      return false;
    }
    return splitAuthorSegments(text).length > 0;
  }

  function collectRenderedAuthorLines(index, domLines, pageRect) {
    const front = domLines.filter(line => {
      const relTop = line.bounds.top - pageRect.top;
      return relTop >= -4 && relTop < pageRect.height * 0.68;
    });
    const stopIndex = front.findIndex(line => STOP_RE.test(line.text));
    const limited = stopIndex > 0 ? front.slice(0, stopIndex) : front.slice(0, Math.min(front.length, 32));
    const lineHeights = limited.map(l => l.bounds.height).filter(h => h > 0).sort((a, b) => a - b);
    const refHeight = lineHeights.length >= 3 ? lineHeights[Math.floor(lineHeights.length / 2)] : 0;
    const selected = [];
    const firstAff = limited.findIndex(line => AFFILIATION_RE.test(line.text) || /\S+@\S+/.test(line.text));

    if (firstAff > 0) {
      let previousTop = limited[firstAff].bounds.top;
      let foundAuthorLine = false;
      let authorHeight = 0;
      for (let i = firstAff - 1; i >= Math.max(0, firstAff - 8); i--) {
        const line = limited[i];
        const lineH = line.bounds.height;
        const gap = previousTop - line.bounds.top - line.bounds.height;
        if (foundAuthorLine && gap > Math.max(28, line.bounds.height * 2.2)) {
          break;
        }
        if (foundAuthorLine && authorHeight > 0 && lineH > authorHeight * 1.3) {
          break;
        }
        if (isLikelyRenderedAuthorLine(line, pageRect)) {
          addUniqueLine(selected, line);
          foundAuthorLine = true;
          if (!authorHeight || lineH < authorHeight) {
            authorHeight = lineH;
          }
          previousTop = line.bounds.top;
        } else if (foundAuthorLine) {
          break;
        }
      }
      for (let i = firstAff + 1; i < limited.length; i++) {
        const line = limited[i];
        if (STOP_RE.test(line.text)) break;
        if (isLikelyRenderedAuthorLine(line, pageRect)) {
          let nearAff = false;
          for (let j = i + 1; j <= Math.min(i + 3, limited.length - 1); j++) {
            if (AFFILIATION_RE.test(limited[j].text) || /\S+@\S+/.test(limited[j].text)) {
              nearAff = true;
              break;
            }
          }
          if (nearAff) {
            addUniqueLine(selected, line);
          }
        }
      }
    }

    const indexedAuthors = index.authors || [];
    const indexedKeys = indexedAuthors.map(author => authorKey(author.name)).filter(Boolean);
    for (let i = 0; i < limited.length; i++) {
      if (refHeight > 0 && limited[i].bounds.height > refHeight * 1.3) {
        continue;
      }
      const lineKey = normalizeNameSearch(limited[i].text).text;
      if (indexedKeys.some(key => key && lineKey.includes(key))) {
        addUniqueLine(selected, limited[i]);
        for (const neighbor of [limited[i - 1], limited[i + 1]]) {
          if (neighbor && isLikelyRenderedAuthorLine(neighbor, pageRect)) {
            addUniqueLine(selected, neighbor);
          }
        }
      }
    }

    selected.sort((a, b) => a.bounds.top - b.bounds.top || a.bounds.left - b.bounds.left);
    return selected;
  }

  function collectRenderedAuthors(index, domLines, pageRect) {
    const additions = [];
    const lines = collectRenderedAuthorLines(index, domLines, pageRect);
    const globalAffiliations = index.affiliations || [];
    const globalHint = globalAffiliations.join(" ");
    for (const line of lines) {
      const sourceText = line.authorText || line.text;
      const lineIdx = domLines.indexOf(line);
      const wrappedLines = domLines.map(l => ({ text: l.authorText || l.text }));
      const localAffs = lineIdx >= 0 ? findNearestAffiliation(lineIdx, wrappedLines, 5) : [];
      const authorInstitutions = localAffs.length ? localAffs : globalAffiliations;
      const authorAffHint = localAffs.length ? localAffs.join(" ") : globalHint;
      for (const segment of splitAuthorSegments(sourceText)) {
        if (!isNameCandidate(segment.name)) {
          continue;
        }
        additions.push({
          name: segment.name,
          page: 1,
          lineText: sourceText,
          affiliationHint: authorAffHint,
          institutions: authorInstitutions,
          top: NaN
        });
      }
    }
    return additions;
  }

  function mergeAuthors(primary, secondary) {
    const merged = [];
    const seen = new Set();
    for (const author of [...primary, ...secondary]) {
      const key = authorKey(author.name);
      if (!key || seen.has(key)) {
        continue;
      }
      seen.add(key);
      merged.push(author);
      if (merged.length >= MAX_AUTHORS) {
        break;
      }
    }

    const keys = merged.map(author => authorKey(author.name));
    return merged.filter((author, index) => {
      const key = keys[index];
      const gluedAffiliation = keys.some((other, otherIndex) => {
        return otherIndex !== index && other && key.length === other.length + 1 && key.startsWith(other) && /^[a-z]$/.test(key.slice(-1));
      });
      if (gluedAffiliation) {
        return false;
      }
      const contained = keys.filter((other, otherIndex) => otherIndex !== index && other && key.includes(other));
      return !(key.split(/\s+/).length > 3 && contained.length >= 2);
    });
  }

  function addAuthorButton(layer, pageRect, rect, author) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "gsr-author-ref";
    button.dataset.authorName = author.name;
    button.dataset.affiliationHint = author.affiliationHint || "";
    button.setAttribute("aria-label", "Preview Google Scholar author page for " + author.name);
    button.title = "Google Scholar: " + author.name;
    button.style.left = rect.left - pageRect.left + "px";
    button.style.top = rect.top - pageRect.top + "px";
    button.style.width = Math.max(20, rect.width) + "px";
    button.style.height = Math.max(14, rect.height) + "px";
    button.addEventListener("pointerenter", event => {
      clearHideTimer();
      showPreview(author, event.currentTarget, false);
    });
    button.addEventListener("focus", event => {
      clearHideTimer();
      showPreview(author, event.currentTarget, false);
    });
    button.addEventListener("pointerleave", scheduleHide);
    button.addEventListener("click", event => {
      event.preventDefault();
      event.stopPropagation();
      showPreview(author, event.currentTarget, true);
    });
    layer.appendChild(button);
  }

  async function annotatePage(pageElement) {
    const index = await buildIndex();
    if (pageElement.getAttribute("data-pn") !== "1") {
      return;
    }
    const textLayer = pageElement.querySelector(".gsr-text-ctn");
    if (!textLayer) {
      return;
    }
    const layer = ensureLayer(pageElement);
    const pageRect = pageElement.getBoundingClientRect();
    const domLines = makeDomLines(textLayer);
    const authors = mergeAuthors(index.authors, collectRenderedAuthors(index, domLines, pageRect));
    if (!authors.length) {
      layer.textContent = "";
      layer.dataset.signature = "";
      return;
    }
    const signature = [
      textLayer.children.length,
      textLayer.textContent.length,
      pageElement.clientWidth,
      pageElement.clientHeight,
      authors.map(author => author.name).join("|")
    ].join(":");
    if (layer.dataset.signature === signature) {
      return;
    }
    layer.dataset.signature = signature;
    layer.textContent = "";

    const seen = new Set();
    for (const author of authors) {
      const candidates = [];
      for (const line of domLines) {
        const match = findNameInDomLine(line, author.name);
        if (!match) {
          continue;
        }
        const score = scoreDomAuthorLine(line, author, pageRect, index.page);
        if (score < 0) {
          continue;
        }
        candidates.push({ line, match, score });
      }
      candidates.sort((a, b) => b.score - a.score || a.line.bounds.top - b.line.bounds.top);
      const candidate = candidates[0];
      if (!candidate) {
        continue;
      }
      const rect = rectFromDomLine(candidate.line, candidate.match.start, candidate.match.end);
      if (!rect || !rect.width || !rect.height) {
        continue;
      }
      const key = [
        author.name.toLowerCase(),
        Math.round(rect.left),
        Math.round(rect.top),
        Math.round(rect.width),
        Math.round(rect.height)
      ].join(":");
      if (seen.has(key)) {
        continue;
      }
      seen.add(key);
      addAuthorButton(layer, pageRect, rect, author);
    }
  }

  function annotateRenderedAuthors() {
    const page = document.querySelector('.gsr-page[data-pn="1"]');
    if (page) {
      annotatePage(page);
    }
  }

  function scheduleAnnotate() {
    if (state.scheduled) {
      return;
    }
    state.scheduled = true;
    const run = function () {
      if (!state.scheduled) {
        return;
      }
      state.scheduled = false;
      annotateRenderedAuthors();
    };
    requestAnimationFrame(run);
    setTimeout(run, 100);
  }

  function clearHideTimer() {
    if (state.hideTimer) {
      clearTimeout(state.hideTimer);
      state.hideTimer = 0;
    }
  }

  function scheduleHide() {
    clearHideTimer();
    if (state.pinned) {
      return;
    }
    state.hideTimer = setTimeout(closePreview, 260);
  }

  function ensurePreview() {
    if (state.preview) {
      return state.preview;
    }
    const panel = document.createElement("div");
    panel.className = "gsr-author-preview";
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-label", "Google Scholar author preview");

    const header = document.createElement("div");
    header.className = "gsr-author-preview-header";
    const title = document.createElement("div");
    title.className = "gsr-author-preview-title";
    const close = document.createElement("button");
    close.type = "button";
    close.className = "gsr-author-preview-close";
    close.setAttribute("aria-label", "Close author preview");
    close.title = "Close";
    close.innerHTML = '<svg viewBox="0 0 21 21"><path d="M16.6 5.6L15.3 4.3L10.5 9.2L5.6 4.3L4.3 5.6L9.2 10.5L4.3 15.3L5.6 16.6L10.5 11.7L15.3 16.6L16.6 15.3L11.7 10.5L16.6 5.6Z"/></svg>';
    header.append(title, close);

    const body = document.createElement("div");
    body.className = "gsr-author-preview-body";
    panel.append(header, body);
    document.body.appendChild(panel);

    panel.addEventListener("pointerenter", clearHideTimer);
    panel.addEventListener("pointerleave", scheduleHide);
    close.addEventListener("click", event => {
      event.preventDefault();
      closePreview();
    });
    document.addEventListener("keydown", event => {
      if (event.key === "Escape") {
        closePreview();
      }
    });
    document.addEventListener("pointerdown", event => {
      const target = event.target;
      const inAuthorRef = target instanceof Element && target.closest(".gsr-author-ref");
      if (state.pinned && !panel.contains(target) && !inAuthorRef) {
        closePreview();
      }
    }, true);

    state.preview = { panel, title, body };
    return state.preview;
  }

  function positionPreview(anchor) {
    const preview = ensurePreview();
    const panel = preview.panel;
    const anchorRect = anchor.getBoundingClientRect();
    panel.style.left = "12px";
    panel.style.top = "12px";
    panel.classList.add("gsr-vis");
    const panelRect = panel.getBoundingClientRect();
    const left = clamp(anchorRect.left, 12, window.innerWidth - panelRect.width - 12);
    let top = anchorRect.bottom + 10;
    if (top + panelRect.height > window.innerHeight - 12) {
      top = Math.max(12, anchorRect.top - panelRect.height - 10);
    }
    panel.style.left = left + "px";
    panel.style.top = top + "px";
  }

  function setStatus(message) {
    const preview = ensurePreview();
    preview.body.textContent = "";
    const status = document.createElement("div");
    status.className = "gsr-author-preview-status";
    status.textContent = message;
    preview.body.appendChild(status);
  }

  function closePreview() {
    clearHideTimer();
    state.token++;
    state.pinned = false;
    if (state.preview) {
      state.preview.panel.classList.remove("gsr-vis", "gsr-pinned");
      state.preview.body.textContent = "";
    }
  }

  function authorSearchUrl(query) {
    return SCHOLAR_ORIGIN + "/citations?view_op=search_authors&mauthors=" + encodeURIComponent(query) + "&hl=en";
  }

  function makeQueries(author) {
    const queries = [];
    const institutions = (author.institutions || []).filter(Boolean);
    if (institutions.length) {
      queries.push(author.name + " " + institutions[0]);
    }
    if (author.affiliationHint && author.affiliationHint !== institutions[0]) {
      queries.push(author.name + " " + author.affiliationHint.slice(0, 100));
    }
    queries.push(author.name);
    return [...new Set(queries.map(query => query.replace(/\s+/g, " ").trim()).filter(Boolean))];
  }

  async function fetchAuthorSearch(query) {
    const response = await fetch(authorSearchUrl(query), {
      credentials: "include",
      signal: AbortSignal.timeout ? AbortSignal.timeout(8000) : void 0
    });
    if (!response.ok) {
      throw Error("HTTP " + response.status);
    }
    return parseAuthorResults(await response.text(), query);
  }

  function safeScholarUrl(href) {
    try {
      const url = new URL(href, SCHOLAR_ORIGIN);
      return url.origin === SCHOLAR_ORIGIN ? url.toString() : "";
    } catch (error) {
      return "";
    }
  }

  function parseAuthorResults(html, query) {
    const doc = new DOMParser().parseFromString(html, "text/html");
    if (doc.querySelector("#gs_captcha_f, form[action*='sorry']")) {
      return { blocked: true, results: [], query };
    }
    const results = [];
    for (const card of doc.querySelectorAll(".gs_ai_chpr")) {
      const nameLink = card.querySelector(".gs_ai_name a");
      const name = (nameLink?.textContent || "").trim();
      const href = nameLink ? safeScholarUrl(nameLink.getAttribute("href") || "") : "";
      if (!name || !href) {
        continue;
      }
      const affiliation = (card.querySelector(".gs_ai_aff")?.textContent || "").trim();
      const email = (card.querySelector(".gs_ai_eml")?.textContent || "").trim();
      const cited = (card.querySelector(".gs_ai_cby")?.textContent || "").trim();
      const interests = Array.from(card.querySelectorAll(".gs_ai_int a"))
        .map(link => link.textContent.trim())
        .filter(Boolean)
        .slice(0, 4);
      results.push({ name, href, affiliation, email, cited, interests, query });
    }
    return { blocked: false, results, query };
  }

  function rankResults(results, author) {
    const last = author.name.split(/\s+/).pop().toLowerCase();
    const affiliation = (author.affiliationHint || "").toLowerCase();
    return results.map(result => {
      let score = 0;
      const resultName = result.name.toLowerCase();
      const resultAff = result.affiliation.toLowerCase();
      if (resultName === author.name.toLowerCase()) {
        score += 10;
      }
      if (last && resultName.includes(last)) {
        score += 4;
      }
      for (const token of affiliation.split(/[^a-z]+/).filter(token => token.length > 4)) {
        if (resultAff.includes(token)) {
          score += 2;
        }
      }
      return { ...result, score };
    }).sort((a, b) => b.score - a.score);
  }

  async function getScholarResults(author) {
    const cacheKey = author.name + "|" + (author.affiliationHint || "");
    if (state.cache.has(cacheKey)) {
      return state.cache.get(cacheKey);
    }
    const queries = makeQueries(author);
    const all = [];
    let blocked = false;
    for (const query of queries) {
      try {
        const parsed = await fetchAuthorSearch(query);
        blocked = blocked || parsed.blocked;
        all.push(...parsed.results);
        if (parsed.results.length) {
          break;
        }
      } catch (error) {
        console.warn("Google Scholar Reader author preview: search failed", query, error);
      }
    }
    const deduped = [];
    const seen = new Set();
    for (const result of all) {
      if (seen.has(result.href)) {
        continue;
      }
      seen.add(result.href);
      deduped.push(result);
    }
    const value = { blocked, queries, results: rankResults(deduped, author).slice(0, MAX_RESULTS) };
    state.cache.set(cacheKey, value);
    return value;
  }

  function renderResults(author, data) {
    const preview = ensurePreview();
    preview.body.textContent = "";

    const queryLine = document.createElement("div");
    queryLine.className = "gsr-author-preview-query";
    queryLine.textContent = "Search: " + data.queries[0];
    preview.body.appendChild(queryLine);

    if (data.results.length) {
      for (const result of data.results) {
        const card = document.createElement("a");
        card.className = "gsr-author-preview-result";
        card.href = result.href;
        card.target = "_blank";
        card.rel = "noopener noreferrer";

        const name = document.createElement("div");
        name.className = "gsr-author-preview-result-name";
        name.textContent = result.name;
        const affiliation = document.createElement("div");
        affiliation.className = "gsr-author-preview-result-aff";
        affiliation.textContent = result.affiliation || "Google Scholar profile";
        card.append(name, affiliation);

        if (result.email || result.cited) {
          const meta = document.createElement("div");
          meta.className = "gsr-author-preview-result-meta";
          meta.textContent = [result.email, result.cited].filter(Boolean).join(" - ");
          card.appendChild(meta);
        }
        if (result.interests.length) {
          const interests = document.createElement("div");
          interests.className = "gsr-author-preview-result-interests";
          interests.textContent = result.interests.join(", ");
          card.appendChild(interests);
        }
        preview.body.appendChild(card);
      }
      return;
    }

    const fallback = document.createElement("a");
    fallback.className = "gsr-author-preview-fallback";
    fallback.href = authorSearchUrl(data.queries[0] || author.name);
    fallback.target = "_blank";
    fallback.rel = "noopener noreferrer";
    fallback.textContent = data.blocked ? "Open Google Scholar author search" : "No profile matched. Open Scholar search";
    preview.body.appendChild(fallback);
  }

  async function showPreview(author, anchor, pinned) {
    const preview = ensurePreview();
    clearHideTimer();
    state.pinned = !!pinned;
    state.token++;
    const token = state.token;
    preview.panel.classList.toggle("gsr-pinned", state.pinned);
    preview.title.textContent = author.name;
    setStatus("Searching Google Scholar...");
    positionPreview(anchor);

    const data = await getScholarResults(author);
    if (token !== state.token) {
      return;
    }
    renderResults(author, data);
    positionPreview(anchor);
  }

  async function start() {
    await waitForApi();
    scheduleAnnotate();
    buildIndex().catch(error => {
      console.warn("Google Scholar Reader author preview: index failed", error);
    });
    new MutationObserver(scheduleAnnotate).observe(document.body, { childList: true, subtree: true });
    window.addEventListener("resize", scheduleAnnotate);
    window.addEventListener("scroll", scheduleAnnotate, true);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
